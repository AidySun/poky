#include <stdio.h>
#include "helloprint.h"

void printHello(void) {
    printf("Hello Yocto!!!\n");
    return;
}